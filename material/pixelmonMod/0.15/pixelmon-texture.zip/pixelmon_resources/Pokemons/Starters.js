{
		choice1:Pokemon.bulbasaur,
		choice2:Pokemon.charmander,
		choice3:Pokemon.squirtle
}
